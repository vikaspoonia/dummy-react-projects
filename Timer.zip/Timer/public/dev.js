function first() {
   console.log(1);
   
}

function second(){
    console.log(2);
    
}

first();
second();