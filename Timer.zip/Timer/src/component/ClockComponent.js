import React from 'react';

function ClockComponent(props){
 
    return (
        <div>
            <p>{Math.floor(props.timer/60)}: {props.timer%60}</p>
            <button onClick={()=>props.handleTimer(props.timer)}>Start</button>
         <button onClick={()=>props.handleReset()}>Reset</button>
         <button onClick ={()=>props.handleOnStop("stop")}>Stop</button>
        </div>
    )
}

export default ClockComponent