import React, { Component } from 'react';
import ClockComponent from './ClockComponent'


class App extends Component {
   constructor(props){
         super(props)

         this.state ={
           timer: 25*60,
           active: false,
           reset: false,
           stop: false 
         }
         this.handleTimer = this.handleTimer.bind(this)
         this.handleReset = this.handleReset.bind(this)
   }

   componentDidUpdate(prevProps, prevState){
       if(this.state.timer>0&& this.state.active===true&& this.state.reset===false){
         console.log("---Update---");
         
        this.handleTimer(this.state.timer);
       }
        
   }

   handleTimer(value){
     console.log(value);
     
     let timer;
   
     timer=window.setTimeout(() => {
      this.setState({
        timer : value -1,
        active:true,
        reset: false
      })
     }, 1000);
  
       if(this.state.timer<=0&&!this.state.active){
         console.log("Cleared");
         
         
         this.handleReset(timer)
       }
    
     
    
   }
  
   handleReset(timer){
     
     const value = 25*60;
    this.setState({
      timer : value,
      active: false,
      reset: true
    })
    
    
   }

    handleOnStop(){
      clearInterval()
    }

   render(){
     return (
       <div className="division">
         <h2>Pomodoro App</h2>
         <ClockComponent timer={this.state.timer} 
         handleTimer ={this.handleTimer}
         handleReset ={this.handleReset}
         handleOnStop = {this.handleOnStop}
         />
       
       </div>
     )
   }
     
      
}

export default App;
