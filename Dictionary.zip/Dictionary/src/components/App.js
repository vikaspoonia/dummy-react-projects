import React, { Component } from 'react';
import DictionaryView from './DictionaryView.js'





class App extends Component {
	// In constructor method include API key from Collins dictionary
	// You can see API usage from  this https://www.collinsdictionary.com/api/collins-english-dictionary,61,HCA.html
	// For applying follow this link:https://www.collinsdictionary.com/api/register,58,HCA.html
	// This programs only reads all the meaning of the words if available
  constructor(props){
       super(props)

       this.state ={
				 dictionary:[],
				 input:"",
				 APIkey:""
			 }
			 this.handleInput = this.handleInput.bind(this)
			 this.handleSearch = this.handleSearch.bind(this)
  }
 
	
	

	

	handleSearch(value){
		console.log("---handlesearch---");
		
		console.log(value);
	
	
		
		const url = encodeURI(`https://www.dictionaryapi.com/api/v3/references/thesaurus/json/${value}?key=:${this.APIkey}`)
    fetch(url).then(resp=>resp.json())
    .then(data=> {if(typeof data!== undefined){this.setState({
      dictionary: data
    })}})
    .catch(error=>console.log(error));
	}
	
	handleInput(event){
		
		const value = event.target.value
		this.setState({
			input :value
		})
	}
  render() {
			 console.log(this.state.input);
			 console.log(this.state.dictionary);
			 
       
    
    return (
      <div>
        <DictionaryView 
				dictionary={this.state.dictionary} 
				handleInput = {this.handleInput}
				handleSearch ={this.handleSearch}
				input ={this.state.input}
				/>
			
			

      </div>
    );
  }
}

export default App;
