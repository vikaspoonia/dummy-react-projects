import  React from "react"
import { Button, Input, InputGroupAddon, InputGroup, ListGroup, ListGroupItem,ListGroupItemHeading, ListGroupItemText  } from 'reactstrap';


export default function DictionaryView(props){

    return (
        <div >
        <InputGroup>
          <InputGroupAddon addonType="prepend"><Button color="primary" onClick={()=>props.handleSearch(props.input)}> Search</Button></InputGroupAddon>
          <Input type="text" placeholder="type your word" onChange={props.handleInput}/>
        </InputGroup>
            
         <ListGroup>
                 {props.dictionary.map(function(item, index){
                     return <ListGroupItem key={index}>
                         <ListGroup>{item.shortdef.map(function(item, index){
                         return <ListGroupItem key={index}>
                             {item}
                             </ListGroupItem> })}
                                </ListGroup>
                             </ListGroupItem>
                 })}
             </ListGroup>
         
        </div>
    
    )
} 

  
